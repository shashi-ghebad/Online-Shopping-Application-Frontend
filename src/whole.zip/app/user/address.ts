export interface Address {
    streetNo: string,
    buildingName: string,
    city: string,
    state: string,
    country: string,
    pincode: any
  }