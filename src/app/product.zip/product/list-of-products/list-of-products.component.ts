import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';
import { CartService } from 'src/app/cartdetails/cart.service';
import { Customer } from 'src/app/user/customer';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-list-of-products',
  templateUrl: './list-of-products.component.html',
  styleUrls: ['./list-of-products.component.css']
})
export class ListOfProductsComponent implements OnInit {

  
  title: string = "LIST OF PRODUCTS";
  //showForm: boolean = false;
  allProducts: Product[] = [];
 
  myError = '';

  username!: string;

  customer!: Customer;

  

  constructor(private productService: ProductService,
              private router : Router,
              private authService: AuthService,
              private cartService: CartService,
              private route: ActivatedRoute) { }

  ngOnInit(): void {
    console.log(this.route.snapshot.paramMap.get('username'));
    this.username = this.route.snapshot.paramMap.get('username')!
    this.productService.getCustomerIdByUsername(this.username).subscribe((response =>{
      console.log(response);
      this.customer = response;
    }))
    this.productService.getAllProducts().subscribe((response) => {
      console.log(response);
      this.allProducts = response;
    },
    (error) => {
      console.log(error.error.message);
      this.myError = error.error.message;
    });
    console.log("this is after the asynchronous call");
  }

  editProduct(prodId: number){
    console.log(prodId);
    //this.productService.updateProduct();
    this.router.navigate(['edit-product', prodId]);
  }

  deleteProduct(prodId: number) {
    console.log(prodId);
    this.productService.deleteProduct(prodId).subscribe((response)=>{
      console.log(response);
      this.allProducts=response;
    },
    (error) =>{
      console.log(error.error.message);
      this.allProducts = [];
      this.myError=error.error.message;
    });
  }

  // addToCart() :void {
  //   this.router.navigate(['cart']);
  // }

  addToCart(product: Product) {
   // this.productAddToCart.emit(this.product);
   // this.router.navigate(['cart']);
   let cartItem = {
     cartId: 0,
     addingDate: new Date(),
     productId: [{
       ...product,
     }],
     customer: {
       ...this.customer
     }
   }
   console.log(cartItem);
   this.cartService.addToCart(cartItem).subscribe(response =>{
     console.log(response);
   })
  }


  getRole() {
    return this.authService.getRole();
  }
  
  getUser() {
    return this.authService.retrieveUserDetails();
  }

}
