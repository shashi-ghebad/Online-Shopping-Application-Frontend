import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  editForm: FormGroup;
  constructor(private customerService: CustomerService,
    private activatedRoute: ActivatedRoute,
    private router: Router) 
    {
    this.editForm = new FormGroup({
      customerId: new FormControl(),
      firstName: new FormControl(),
      lastName: new FormControl(),
      mobileNumber: new FormControl(),
      email: new FormControl(),
      streetNo: new FormControl(),
      buildingName: new FormControl(),
      city: new FormControl(),
      state: new FormControl(),
      country: new FormControl(),
      pincode: new FormControl(),
      userName: new FormControl(),
      password: new FormControl()
    })
  }

  ngOnInit(): void {
    let customer: any = this.activatedRoute.snapshot.paramMap.get('custId');
       this.customerService.getCustomer(customer).subscribe((response) => {
      this.editForm.setValue(response);
      console.log(response);
    });
  }


  editCustomer() {
    console.log(this.editForm);
    console.log(this.editForm.value);
    this.customerService.updateCustomer(this.editForm.value).subscribe((response) => {
      console.log(response);
      this.router.navigate(['list-of-products', 'username']);
    });

  }

}
