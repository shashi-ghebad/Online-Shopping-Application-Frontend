import { Injectable } from "@angular/core";
import { Cart } from "../cartdetails/cart";


@Injectable()
export class CartDataService{
    cartData!: any
}