import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { CartService } from '../cartdetails/cart.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private authService: AuthService, private cartService: CartService) { }

  ngOnInit(): void {
  }
  
  getRole() {
    return this.authService.getRole();
  }
  
  getUser() {
    return this.authService.retrieveUserDetails();
  }
  // viewCart(){
  //   return this.cartService.getCartItems();
  // }
}
