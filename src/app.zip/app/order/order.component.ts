import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Order } from '../order';
import { Product } from '../product/product';
import { ProductService } from '../product/product.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

myOrder: any;

  constructor(private activatedRoute: ActivatedRoute,
    private productService: ProductService,
    private router: Router) { }

  ngOnInit(): void {
    let orderId: any = this.activatedRoute.snapshot.paramMap.get('orderId');
    console.log(orderId);
    this.productService.findOrderByOrderId(orderId).subscribe(response =>{
      console.log(response);
      this.myOrder = response;
    })
  }

  goToList(){
    this.router.navigate(['list-of-products', this.myOrder.customer.username]);
  }

}
