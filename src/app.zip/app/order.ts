import { Product } from "./product/product";
import { Customer } from "./user/customer";
import { User } from "./user/User";

export interface Order{
    orderId: number,
    orderDate: any,
    orderStatus: string,
    product: Product[],
    customer: Customer
}